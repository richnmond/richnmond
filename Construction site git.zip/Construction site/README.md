# Construction Website Design
### This design is inspired by the work of [Mr. Web Designer](https://www.youtube.com/@MrWebDesignerAnas). Click [here](https://youtu.be/Lh4ui-FBTzI) to watch the video.

![preview img](/preview.png)
